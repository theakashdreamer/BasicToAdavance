package com.skysoftsolution.basictoadavance.dashBoardScreens.entity
data class ModuleForUse(val id: Int, val Title: String, val drawable: Int)