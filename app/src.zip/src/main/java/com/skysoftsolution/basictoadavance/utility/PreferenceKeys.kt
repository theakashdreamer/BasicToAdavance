package com.skysoftsolution.thingisbeing.utility

class PreferenceKeys {
    companion object {
        val PUBLICDATA: String = "PUBLICDATA"
        val OTP_SCREEN_STATUS: String = "OTP_SCREEN_STATUS"
        val PIN_GENERATE_BOOLEAN: String = "PIN_GENERATE_BOOLEAN"
        val PIN_GENERATE: String = "PIN_GENERATE"
        val OTP_Model: String = "OTP_Model"
        val URL1: String = "URL1"
        val USER_NAME: String = "USER_NAME"
        val USER_DETAILS: String = "USER_DETAILS"
        val MOBILE_NUMBER: String = "MOBILE_NUMBER"
        val PRIVACY_POLICY: String = "PRIVACY_POLICY"
        val USER_NAME_STATUS: String = "USER_NAME_STATUS"
        val USER_MOBILE_NUMBER_STATUS: String = "USER_MOBILE_NUMBER_STATUS"
        val LOGIN_SCAREEN: String = "LOGIN_SCAREEN"
    }
}