package com.skysoftsolution.basictoadavance.motiondetectorService;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.skysoftsolution.basictoadavance.R;

public class WarningActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_warning);
    }
}