package com.skysoftsolution.basictoadavance.taskDetails.entity

data class DailyRoutineGroup(
    val date: String,
    val routines: List<AddDailyRoutine>
)
