package com.skysoftsolution.basictoadavance.motiondetectorService;

public class AppMonitorService {
}
