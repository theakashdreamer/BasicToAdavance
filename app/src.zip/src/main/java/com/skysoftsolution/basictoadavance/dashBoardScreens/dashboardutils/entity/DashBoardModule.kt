package com.skysoftsolution.basictoadavance.dashBoardScreens.dashboardutils.entity

data class DashBoardModule(val userList: List<ModuleForUse>)
