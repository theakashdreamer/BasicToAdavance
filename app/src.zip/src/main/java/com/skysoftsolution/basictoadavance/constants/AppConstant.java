package com.skysoftsolution.basictoadavance.constants;

public class AppConstant {

    public static String BASE_URL = "https://spassess.technosysservicesdemos.com/api/";
    public static String BASE_URL_Main = "https://spassess.technosysservicesdemos.com/api/";


}
