package com.skysoftsolution.basictoadavance.dashBoardScreens.dashboardutils.entity
data class ModuleForUse(val id: Int, val Title: String, val drawable: Int)