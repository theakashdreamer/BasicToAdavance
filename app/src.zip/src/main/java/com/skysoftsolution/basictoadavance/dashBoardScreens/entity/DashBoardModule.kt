package com.skysoftsolution.thingisbeing.dashBoard.dashboardutils.entity

import com.skysoftsolution.basictoadavance.dashBoardScreens.dashboardutils.entity.ModuleForUse

data class DashBoardModule(val userList: List<ModuleForUse>)
